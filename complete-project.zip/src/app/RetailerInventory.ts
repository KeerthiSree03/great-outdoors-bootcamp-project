export class RetailerInventory2{
    retailerId:string;
    productCategoryNumber:number;
    productId:string;
    productUniqueId:string;
    productDispatchTimestamp:Date;
    productReceiveTimestamp:Date;
    deliveryTimePeriod:number;
}

export class RetailerInventoryList{
    public rIlist:RetailerInventory2[];
}