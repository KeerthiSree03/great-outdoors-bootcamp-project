import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { RetailerComponent } from './retailer/retailer.component';
import { SalesRepresentativeComponent } from './sales-representative/sales-representative.component';
import { ProductMasterComponent } from './product-master/product-master.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LogoutComponent } from './logout/logout.component';
import { ReportsComponent } from './reports/reports.component';
import { CategorylevelreportComponent } from './categorylevelreport/categorylevelreport.component';
import { CategorywisereportComponent } from './categorywisereport/categorywisereport.component';
import { ItemlevelreportComponent } from './itemlevelreport/itemlevelreport.component';
import { ItemwisereportComponent } from './itemwisereport/itemwisereport.component';
import { OutlierlevelreportComponent } from './outlierlevelreport/outlierlevelreport.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    AdminComponent,
    RetailerComponent,
    SalesRepresentativeComponent,
    ProductMasterComponent,
    LogoutComponent,
    ReportsComponent,
    CategorylevelreportComponent,
    CategorywisereportComponent,
    ItemlevelreportComponent,
    ItemwisereportComponent,
    OutlierlevelreportComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [Title],
  bootstrap: [AppComponent]
})
export class AppModule { }
