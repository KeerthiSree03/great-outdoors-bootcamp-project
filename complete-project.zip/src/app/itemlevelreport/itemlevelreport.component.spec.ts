import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemlevelreportComponent } from './itemlevelreport.component';

describe('ItemlevelreportComponent', () => {
  let component: ItemlevelreportComponent;
  let fixture: ComponentFixture<ItemlevelreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItemlevelreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemlevelreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
