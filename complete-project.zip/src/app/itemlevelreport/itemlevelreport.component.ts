import { Component, OnInit } from '@angular/core';
import { ItemLevelEntry } from '../ItemLevelEntry';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-itemlevelreport',
  templateUrl: './itemlevelreport.component.html',
  styleUrls: ['./itemlevelreport.component.css']
})
export class ItemlevelreportComponent implements OnInit {
  constructor(private service:UserServiceService) { }


  entries:ItemLevelEntry[];
  entry:ItemLevelEntry;
    ngOnInit(): void {
      
      this.service.viewItemLevelDeliveryTimeReport().subscribe(
        (entries)=>{
            this.entries=entries.list;
            console.log(entries.list)
  
          });
  
          
    }
  

}
