import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserBean } from './UserBean';
import { UserLoginCredentials } from './UserLoginCredentials';
import { Observable } from 'rxjs';
import { ItemLevelEntriesList } from './ItemLevelEntry';
import { CategoryLevelEntriesList } from './CategoryLevelEntry';
import { RetailerInventoryList } from './RetailerInventory';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private httpClient:HttpClient) { }
  private baseUrl="http://localhost:8111/user"

  getUserByUserId(userId:string):Observable<UserBean>{
    return this.httpClient.get<UserBean>(this.baseUrl+"/user-by-id/"+userId);
  }

  login(credentials:UserLoginCredentials):Observable<UserBean>{
    return this.httpClient.post<UserBean>(this.baseUrl+"/login",credentials);
  }

  register(userBean:UserBean):Observable<UserBean>{
    return this.httpClient.post<UserBean>(this.baseUrl+"/register",userBean);
  }

  viewItemLevelDeliveryTimeReport():Observable<ItemLevelEntriesList>{
    return this.httpClient.get<ItemLevelEntriesList>(this.baseUrl+"/delivery-time-report/item-wise");
  }

  viewCategoryLevelDeliveryTimeReport():Observable<CategoryLevelEntriesList>{
    return this.httpClient.get<CategoryLevelEntriesList>(this.baseUrl+"/delivery-time-report/category-wise");
  }

  viewOutlierCategoryLevelDeliveryTimeReport():Observable<CategoryLevelEntriesList>{
    return this.httpClient.get<CategoryLevelEntriesList>(this.baseUrl+"/delivery-time-report/outlier-category-wise");
  }

  viewItemLevelDeliveryTimeReportByProductId(productId:string):Observable<RetailerInventoryList>{
    return this.httpClient.get<RetailerInventoryList>(this.baseUrl+"/delivery-time-report/item-wise/"+productId);
  }

  viewCategoryLevelDeliveryTimeReportByCategoryId(categoryNumber:number):Observable<RetailerInventoryList>{
    return this.httpClient.get<RetailerInventoryList>(this.baseUrl+"/delivery-time-report/category-wise/"+categoryNumber);
  }
}
