import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-representative',
  templateUrl: './sales-representative.component.html',
  styleUrls: ['./sales-representative.component.css']
})
export class SalesRepresentativeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
