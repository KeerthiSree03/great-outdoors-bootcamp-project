import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-master',
  templateUrl: './product-master.component.html',
  styleUrls: ['./product-master.component.css']
})
export class ProductMasterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
