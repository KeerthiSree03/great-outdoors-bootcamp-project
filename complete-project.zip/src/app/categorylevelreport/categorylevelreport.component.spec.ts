import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategorylevelreportComponent } from './categorylevelreport.component';

describe('CategorylevelreportComponent', () => {
  let component: CategorylevelreportComponent;
  let fixture: ComponentFixture<CategorylevelreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CategorylevelreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CategorylevelreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
