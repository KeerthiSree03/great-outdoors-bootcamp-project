import { Component, OnInit } from '@angular/core';
import { CategoryLevelEntry } from '../CategoryLevelEntry';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-categorylevelreport',
  templateUrl: './categorylevelreport.component.html',
  styleUrls: ['./categorylevelreport.component.css']
})
export class CategorylevelreportComponent implements OnInit {

  constructor(private service:UserServiceService) { }
  entries:CategoryLevelEntry[];
  entry:CategoryLevelEntry;
  ngOnInit(): void {

    this.service.viewCategoryLevelDeliveryTimeReport().subscribe(
      (entries)=>{
          this.entries=entries.list;
          console.log(entries.list)

        });

  }

}
