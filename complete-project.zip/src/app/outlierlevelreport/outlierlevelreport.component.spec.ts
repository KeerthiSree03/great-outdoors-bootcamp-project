import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OutlierlevelreportComponent } from './outlierlevelreport.component';

describe('OutlierlevelreportComponent', () => {
  let component: OutlierlevelreportComponent;
  let fixture: ComponentFixture<OutlierlevelreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OutlierlevelreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OutlierlevelreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
