import { Component, OnInit } from '@angular/core';
import { CategoryLevelEntry } from '../CategoryLevelEntry';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-outlierlevelreport',
  templateUrl: './outlierlevelreport.component.html',
  styleUrls: ['./outlierlevelreport.component.css']
})
export class OutlierlevelreportComponent implements OnInit {

  constructor(private service:UserServiceService) { }
  entries:CategoryLevelEntry[];
  entry:CategoryLevelEntry;
  ngOnInit(): void {

    this.service.viewOutlierCategoryLevelDeliveryTimeReport().subscribe(
      (entries)=>{
          this.entries=entries.list;
          console.log(entries.list)

        });

  }
}
