import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';
import { UserBean } from '../UserBean';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private router:Router, public service: UserServiceService ) { }
  public userBean:UserBean=new UserBean(); 
  
  ngOnInit(): void {
  }

  selectUserType:string='';

  selectChangeHandler (event: any) {
    this.selectUserType = event.target.value;
  }
   

  register(){
    this.userBean.userType=this.selectUserType;
    console.log(this.userBean.userType)
      this.service.register(this.userBean).subscribe(
          (success)=>{
            alert("Account Created Successfully...!!! Please login");
            this.router.navigate(["/login"]);
          },
          (error)=>{
            alert("Please try again!!!")
          })
      }
  
}
