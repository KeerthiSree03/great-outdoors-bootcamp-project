export class ItemLevelEntry {
    productId:string;
    categoryNumber:number;
    productName:string;
    deliveryTimePeriod:number; 
}

export class ItemLevelEntriesList{
    public list:ItemLevelEntry[];
}