import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';
import { UserBean } from '../UserBean';
import { UserLoginCredentials } from '../UserLoginCredentials';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private service:UserServiceService,private router:Router ) { }

  userLoginCredentials:UserLoginCredentials;
  userBean:UserBean;
  userType:string;

  ngOnInit(): void {
    this.userLoginCredentials=new UserLoginCredentials();
    
  }

  getType():string{

    this.service.getUserByUserId(this.userLoginCredentials.userId).subscribe(
      (b)=>{
        console.log(b)
        console.log(b.userType.toUpperCase())
        if(b.userType.toUpperCase().match("ADMIN")){
          this.userType="ADMIN";
        }
        else if(b.userType.toUpperCase().match("RETAILER")){
          this.userType="RETAILER";
        }
        else if(b.userType.toUpperCase().match("SALES REPRESENTATIVE")){
          this.userType="SALES REPRESENTATIVE";
        }
        else if(b.userType.toUpperCase().match("PRODUCT MASTER")){
          this.userType="PRODUCT MASTER";
        }

        
      }
    )
    console.log(this.userType)
    return this.userType

  }
  login(){
    this.service.login(this.userLoginCredentials).subscribe(
      (success)=>{
console.log(success)
        if(this.getType().match("ADMIN")){
          this.router.navigate(["/admin"]);
        }
        else if(this.getType().match("SALES REPRESENTATIVE")){
          this.router.navigate(["/sales-representative"]);
        }
        else if(this.getType().match("RETAILER")){
          this.router.navigate(["/retailer"]);
        }
        else if(this.getType().match("PRODUCT MASTER")){
          this.router.navigate(["/product-master"]);
        }
        else{
            alert("User not found")
        }
      },
      (error)=>{alert("Invalid Credentials...Please try again!!!")}
    )
  }


}
