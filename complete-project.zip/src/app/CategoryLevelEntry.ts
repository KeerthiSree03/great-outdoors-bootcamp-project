export class CategoryLevelEntry {
    categoryId:number;
    categoryName:string;
    deliveryTimePeriod:number;
}

export class CategoryLevelEntriesList{
    public list:CategoryLevelEntry[];
}