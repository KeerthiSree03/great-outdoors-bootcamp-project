import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { CategorylevelreportComponent } from './categorylevelreport/categorylevelreport.component';
import { CategorywisereportComponent } from './categorywisereport/categorywisereport.component';
import { HomeComponent } from './home/home.component';
import { ItemlevelreportComponent } from './itemlevelreport/itemlevelreport.component';
import { ItemwisereportComponent } from './itemwisereport/itemwisereport.component';
import { LoginComponent } from './login/login.component';
import { OutlierlevelreportComponent } from './outlierlevelreport/outlierlevelreport.component';
import { ProductMasterComponent } from './product-master/product-master.component';
import { RegisterComponent } from './register/register.component';
import { ReportsComponent } from './reports/reports.component';
import { RetailerComponent } from './retailer/retailer.component';
import { SalesRepresentativeComponent } from './sales-representative/sales-representative.component';


const routes: Routes = [
  {
    path:"", component:HomeComponent
  },
  {
    path:"login", component:LoginComponent
  },
  {
    path:"register", component:RegisterComponent
  },
  {
    path:"admin", component:AdminComponent
  },
  {
    path:"retailer", component:RetailerComponent
  },
  {
    path:"sales-representative", component:SalesRepresentativeComponent
  },
  {
    path:"product-master", component:ProductMasterComponent
  },
  {
    path:"admin/reports", component:ReportsComponent
  },
  {
    path:"item-wise", component:ItemlevelreportComponent 
  },
  {
    path:"category-wise", component:CategorylevelreportComponent
  },
  {
    path:"item-wise/productId", component:ItemwisereportComponent
  },
  {
    path:"category-wise/categoryNumber", component:CategorywisereportComponent
  },
  {
    path:"outlier-category-wise", component:OutlierlevelreportComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
