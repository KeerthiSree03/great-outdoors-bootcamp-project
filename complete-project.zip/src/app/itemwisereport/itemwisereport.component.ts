import { Component, OnInit } from '@angular/core';
import { RetailerInventory2 } from '../RetailerInventory';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-itemwisereport',
  templateUrl: './itemwisereport.component.html',
  styleUrls: ['./itemwisereport.component.css']
})
export class ItemwisereportComponent implements OnInit {

  constructor(private service:UserServiceService) { }

  searchText:string;
  entries:RetailerInventory2[];

  ngOnInit(): void {
  }

  search(){
    this.entries=null;
    this.service.viewItemLevelDeliveryTimeReportByProductId(this.searchText).subscribe(
      (entries)=>{
        this.entries=entries.rIlist
        console.log(entries.rIlist)
      },
      (error)=>{
        alert("Data with Product Id "+this.searchText+" doesn't exist!")
      }
    );
  
  }

}
