import { Component, OnInit } from '@angular/core';
import { RetailerInventory2 } from '../RetailerInventory';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-categorywisereport',
  templateUrl: './categorywisereport.component.html',
  styleUrls: ['./categorywisereport.component.css']
})
export class CategorywisereportComponent implements OnInit {

  constructor(private service:UserServiceService) { }
  
  searchText:number;
  entries:RetailerInventory2[];

  ngOnInit(): void {
  }

  search(){
    this.entries=null;
    this.service.viewCategoryLevelDeliveryTimeReportByCategoryId(this.searchText).subscribe(
      (entries)=>{
        this.entries=entries.rIlist
        console.log(entries.rIlist)
      },
      (error)=>{
        alert("Data with Category Number "+this.searchText+" doesn't exist!")
      }
    );
  
  }
}
