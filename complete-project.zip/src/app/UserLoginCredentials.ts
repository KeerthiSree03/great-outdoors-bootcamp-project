export class UserLoginCredentials{
    userId:string;
    password:string;
}