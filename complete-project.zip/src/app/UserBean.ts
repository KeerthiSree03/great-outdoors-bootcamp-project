export class UserBean{
    userType: string;
	userId: string;
	password:string;
	re_enterPassword:string;
	phoneNo:number;
	email:string;
}